If u want custom Sounds.....

1. Create or download your Sound (.wav)
2. drag it into C:\RAPTOR\Sounds
3. Delete Beginning.wav
4. Rename your custom Sound to Beginning.wav

Done